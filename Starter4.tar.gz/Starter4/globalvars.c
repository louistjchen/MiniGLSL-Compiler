/***********************************************************************
 * **YOUR GROUP INFO SHOULD GO HERE**
 * Louis Chen - 1000303502
 * Juntu Chen - 1000659799
 *
 * globalvars.c
 *
 * CSC467 Project Compiler Shared Global Variables
 *
 * This file contains the definition of global variables that are used
 * for communication among the various compiler modules
 **********************************************************************/

#include <stdio.h>


/***********************************************************************
 * FILE global variables.
 * Used to specify sinks for compiler output and sources for compiler
 * input.
 **********************************************************************/
FILE * inputFile;
FILE * outputFile;
FILE * errorFile;
FILE * dumpFile;
FILE * traceFile;
FILE * runInputFile;

/***********************************************************************
 * Control flags, set by main.c, used to cause various optional compiler
 * actions to take place. 
 **********************************************************************/
int errorOccurred;
int suppressExecution;

int traceScanner;
int traceParser;
int traceExecution;

int dumpSource;
int dumpAST;
int dumpSymbols;
int dumpInstructions;

/***********************************************************************
 * Scanner/Parser/AST/Semantics global variables.
 *
 * **NOTE** If you need to add global variables for phases 1 to 4, add
 * them below this comment.
 **********************************************************************/
long configScope = 0;
long configScopeCount[255];
long printScope = 0;
long printScopeDummy[255];
long Scope_num = 0;
long global_dummy_count[255];
long Test_count[255];


