/*
 * Louis Chen - 1000303502
 * Juntu Chen - 1000659799
 *
 *
 * */


#ifndef _SEMANTIC_H
#define _SEMANTIC_H

#include "ast.h"
#include "symbol.h"


int semantic_check( node *ast);
int numArguments(node *ast);


#endif
