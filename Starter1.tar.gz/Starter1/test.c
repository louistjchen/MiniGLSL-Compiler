//#include <stdio.h>

{

/**** yolo this is comment please don't scan me in.   * *? */
	const int a = +2.3;
	a = b + c;
	float hheheh = +0.20;
	float whwh = -20.23;
	return 0;
// wahahawhahahgeoih ???

	L = 0;
}


// a.bEC
// a max
// 0.00001
// 2.000001
